//Definimos ruta previa al archivo php de las consultas
export const PATH_API = 'php/';